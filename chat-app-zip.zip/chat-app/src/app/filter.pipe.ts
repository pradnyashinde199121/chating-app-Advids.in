import { Pipe, PipeTransform } from '@angular/core';


@Pipe({
  name: 'filter'
})

export class FilterPipe implements PipeTransform {
  transform(contact:any, searchText:string): any {
    if (!contact || !searchText) {
      return contact;
  }

  return contact.filter(contactName =>
    contactName.name.toLowerCase().indexOf(searchText.toLowerCase()) !== -1);
}
  }