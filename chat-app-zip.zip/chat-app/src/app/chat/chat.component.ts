
import { Component, OnInit, ViewChild, ElementRef  } from '@angular/core';
import{UploadService} from '../upload.service';
import { HttpEventType, HttpErrorResponse } from '@angular/common/http';
import { of } from 'rxjs';  
import { catchError, map } from 'rxjs/operators'; 
import { DatePipe } from '@angular/common';
import { isNullOrUndefined } from 'util';

@Component({
  selector: 'app-chat',
   templateUrl: './chat.component.html',
   styleUrls: ['./chat.component.css']
})
export class ChatComponent implements OnInit {
  sendMsgs:any=[];
  sendMsg:any;
  contacts:any=[{name:'pradnya',active:'true', text:'hello customer',role:'Dot net Developer', url:'https://clarity-enhanced.net/wp-content/themes/clarity-enhanced/assets/img/bootstrap-chat-app-assets/robocop.jpg'},
  {name:'priya', active:'false',text:'dummy text',role:'UI developer',url:'https://clarity-enhanced.net/wp-content/themes/clarity-enhanced/assets/img/bootstrap-chat-app-assets/robocop.jpg'},
  {name:'prakash',active:'false', text:'data input',role:'UI developer',url:'https://clarity-enhanced.net/wp-content/themes/clarity-enhanced/assets/img/bootstrap-chat-app-assets/robocop.jpg'},
  {name:'shivaji',active:'true', text:'hello customer',role:'Dot net Developer',url:'https://clarity-enhanced.net/wp-content/themes/clarity-enhanced/assets/img/bootstrap-chat-app-assets/robocop.jpg'}];
  currentChat:any;
  currentText:any;
  currentUrl:any;
  currentrole:any;
  searchText:string;
  imgCount:number;
  dummytext:any="hello";
  fileToUpload: File = null;
  msgSend:boolean=false;
  @ViewChild("fileUpload", {static: false}) fileUpload: ElementRef;
  files  = []; 
  public fileData = []; 
  public array=[ 'image/png','image/jpeg'];
  isUploaded: boolean = false;
  isLoaded : boolean=false;
  isProfileLoaded : boolean=false;
  fileDataAdmin:any=[];
  msgDataAdmin:any=[];
  imgDataAdmin:any;
  imgCountAdmin:number;
  myDate:any = new Date();
  constructor(public uploadService:UploadService,private datePipe: DatePipe ) { 
    this.myDate = this.datePipe.transform(this.myDate, '"MMM d, y, h:mm:ss a"');
  }
 
 
  ngOnInit() {
 
  }
  sendMsg1(){
    if(!isNullOrUndefined(this.sendMsg) && this.sendMsg != ''){
    this.sendMsgs.push(this.sendMsg,this.myDate);
    this.sendMsg='';
    this.myDate=new Date();
    this.myDate = this.datePipe.transform(this.myDate, '"MMM d, y, h:mm:ss a"');
    this.msgSend=true;
    this.msgDataAdmin.push(this.sendMsgs);
  }
  }
  startChat(contact){
  
    this.sendMsgs=[];
    this.fileData  = [];
    this.msgSend=false;
 this.currentChat=contact.name;
 this.currentText=contact.text;
 this.currentUrl=contact.url;
 this.currentrole=contact.role;
 this.isProfileLoaded=false;

  }
  adminDetail(){
    this.isProfileLoaded=true;
   
  }
  // displayFile(){
  //   this.uploadFile(File);
  // }
  
  uploadFile(file) {  //step3
    const formData = new FormData();  
    formData.append('file', file.data);  
    file.inProgress = true;  
    this.uploadService.upload(formData).pipe(                //loader start
      map(event => {  
        switch (event.type) {  
          case HttpEventType.UploadProgress:  
            file.progress = Math.round(event.loaded * 100 / event.total);  
            break;  
          case HttpEventType.Response:  
            return event;  
        }  
      }),  
      catchError((error: HttpErrorResponse) => {  
        file.inProgress = false;  
        return of(`${file.data.name} upload failed.`);        //Loader end
      })).subscribe((event: any) => {                         //data from service subscribed and stored in filedata
        if (typeof (event) === 'object') {  
          console.log(event.body);
          event.body.type = file.data.type;
          event.body.name = file.data.name;
          this.fileData.push(event.body);//final data stored in fileData
          this.fileDataAdmin.push(event.body); 
         const countImg=this.fileData.filter(x=>x.type === 'image/png' || x.type === 'image/jpeg')
         this.imgCount=countImg.length;
         const imgDataAdmin=this.fileDataAdmin.filter(y=>y.type === 'image/png' || y.type === 'image/jpeg')
         this.imgCountAdmin=imgDataAdmin.length;
         this.isLoaded= false;
        }  
      });  
     
  }
  private uploadFiles() {  //step2
    this.fileUpload.nativeElement.value = '';  
    this.files.forEach(file => {  
      this.uploadFile(file);  
    });  
    this.isUploaded = true;
}
onClick() {  // step1

  this.files  = []; //empty the array for new request
  const fileUpload = this.fileUpload.nativeElement;
  fileUpload.onchange = () => {  
  for (let index = 0; index < fileUpload.files.length; index++)  
  {  
   const file = fileUpload.files[index];  
   this.files.push({ data: file, inProgress: false, progress: 0});  
  }  
    this.uploadFiles();  
    this.isLoaded=true;
  };  
  fileUpload.click();  
}

}